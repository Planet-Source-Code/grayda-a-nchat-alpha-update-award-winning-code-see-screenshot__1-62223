This package contains 42 (Mostly) Animated Smileys for use in NChat. This is the default pack that comes with both the source and the binary releases of NChat Alpha Build 11. Installation instructions are in the ZIP file, and here:

To use the smiley pack, copy ALL of the files into the folder: <location of NChat>\Smileys, so for example: c:\program files\NChat\Smileys

If you already downloaded a smiley pack from anywhere on www.solidinc.tk, then you need to 'merge' the 2 files together:

1) Open the ORIGINAL Smileys.SMI in Notepad
2) Open the NEW Smileys.SMI in another Notepad
3) COPY EVERY LINE from the NEW Smileys.SMI to the old Smileys.SMI
4) Save the OLD smileys.SMI

There you have it. You will still have your old smileys, but with some new ones. If some are the same, then NChat will use the first one.

If you have any questions regarding this pack, visit www.solidinc.tk and reply to this topic:

http://solidinc.aspfreeserver.com/nchat/index.php?action=post;board=9.0

Smileys here are from: http://www.spacespider.net/smiley.php and are free to use